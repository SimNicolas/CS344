#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <sys/types.h> 
#include <sys/socket.h>
#include <netinet/in.h>

void error(const char *msg){
	perror(msg);
	exit(1);
}

int charToInt (char ch){
	if (ch == ' '){ //if it's a space then it will be 26
		return 26;
	}
	else{
		return (ch - 'A');
	}
	return 0;
}

char intToChar(int num){
	if (num == 26){
		return ' ';
	}
	else{
		return (num + 'A');
	}
}

void encryption(char message[], char key[]){
	int i;
	char final;

	char m;
	char k;

	for(i=0; message[i]; i++){
		m = charToInt(message[i]);
		k = charToInt(key[i]);

		final = charToInt(m + k) % 27;

		message[i] = intToChar(final);
		
	}

	message[i] = '\0';
	return;
}


int main(int argc, char* argv[]){
	
	int listenSocketFD, establishedConnectionFD, portNumber, charsRead;
	socklen_t sizeofClientInfo;
	struct sockaddr_in serverAddress, clientAddress;
	pid_t pid;

	char buffer[256];
	char* message;
	char* key;
	int i;
	int count;
	


	if (argc != 2){//if greater or equal to 2 arguments then incorrect
		fprintf(stderr,"USAGE: %s port\n", argv[0]);
		exit(1);
	}

	memset((char *)&serverAddress, '\0', sizeof(serverAddress));
	portNumber = atoi(argv[1]);
	serverAddress.sin_family = AF_INET;
	serverAddress.sin_port = htons(portNumber);
	serverAddress.sin_addr.s_addr = INADDR_ANY;

	listenSocketFD = socket(AF_INET, SOCK_STREAM, 0);
	if (listenSocketFD < 0){
		error("ERROR opening socket");
	}

	if (bind(listenSocketFD, (struct sockaddr *)&serverAddress, sizeof(serverAddress)) < 0){
		error("ERROR on binding");
	}
	listen(listenSocketFD, 5); //up to 5 connections


	while(1){

		sizeofClientInfo = sizeof(clientAddress);
		establishedConnectionFD = accept(listenSocketFD, (struct sockaddr *)&clientAddress, &sizeofClientInfo);
		
		if (establishedConnectionFD < 0){
			error("ERROR on accept");
		}

		pid = fork();

		switch(pid){
			case -1:
				error("Error in forking process");
				break;

			case 0:
			

				bzero(buffer, sizeof(buffer)); //zero the buffer
				recv(establishedConnectionFD, buffer, sizeof(buffer)-1, 0); //get authentication from client
				if (strcmp(buffer, "decpassword") == 0){
					char reply[] = "correct";
					write(establishedConnectionFD, reply, sizeof(reply));
				}
				//printf("finished with password");
				bzero(buffer, sizeof(buffer));
				//receive size of message being sent
				//receive message
				char messageBuffer [70000];
				char keyBuffer [70000];
				bzero(messageBuffer, sizeof(messageBuffer));
				bzero(keyBuffer, sizeof(keyBuffer));


				
				int McharsRead = recv(establishedConnectionFD, messageBuffer, sizeof(messageBuffer), 0);
				if (McharsRead < 0){
					error("error reading socket");
				}
				//receive key
				int KcharsRead = recv(establishedConnectionFD, keyBuffer, sizeof(keyBuffer), 0);
				if (KcharsRead < 0){
					error("error reading socket");
				}
				//send encrpyted msg
				char response[] = "heres encryption";
				write(establishedConnectionFD, response, sizeof(response));
				

				//encryption(message, key);

				//write(establishedConnectionFD, messageBuffer, sizeof(messageBuffer));



		}

		close(establishedConnectionFD);

		/*
		//once connection is established we receive buffer from connection (but in hw implementation its a little different)
		memset(buffer, '\0', 256);
		charsRead = recv(establishedConnectionFD, buffer, 255, 0);
		if(charsRead < 0){
			error("ERROR reading from socket");

		}
		printf("SERVER: I received this from the client: \"%s\"\n", buffer);

		charsRead = send(establishedConnectionFD, "I am the server, and I got your message", 39, 0);
		if (charsRead < 0){
			error("ERROR writing to socket");
			close(establishedConnectionFD);
		}
		*/
	}
	close(listenSocketFD);
	return 0;






















}