/*
his program creates a key file of specified length. 
The characters in the file generated will be any of the 27 allowed characters, 
generated using the standard UNIX randomization methods.
*/
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
//65-90
int main(int argc, char* argv[]){
	//accept 1 argument (int) and use rand() to build a random key of letters
	//make sure to add newline to end of stdout
	//https://www.dreamincode.net/forums/topic/345187-c-function-that-generates-a-random-string-of-uppercase-letters/
	//https://stackoverflow.com/questions/12907865/how-do-i-fill-an-array-of-random-uppercase-letters-as-a-function-in-c
	if(argc != 2){
		fprintf(stderr, "Must have 1 int argument only");
		exit(1);
	}

	int key_length;
	int random_key;
	int i;
	srand(time(0));

	key_length = atoi(argv[1]);

	for(i = 0; i < key_length; i++){
		random_key = rand() % 27;
		if(random_key == 26){
			printf(" ");
		}
		else{
			printf("%c", 'A'+random_key);
		}
	}
	printf("\n");
	return 0;
}
