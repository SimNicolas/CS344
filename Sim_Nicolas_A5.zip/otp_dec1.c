#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <string.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <netdb.h> 
#include <fcntl.h>
#include <ctype.h>
#include <sys/stat.h>

void error(const char *msg){
	perror(msg);
	exit(1);
}

int main(int argc, char *argv[])
{
	int socketFD, portNumber, charsWritten, charsRead;
	struct sockaddr_in serverAddress;
	struct hostent* serverHostInfo;
	char buffer[256];
	int count = 0;
	int i;
    
    //need 4 arguments - message, key, port#
	if (argc != 4){
		fprintf(stderr,"USAGE: %s message key port\n", argv[0]);
	}

	// Set up the server address struct
	memset((char*)&serverAddress, '\0', sizeof(serverAddress)); // Clear out the address struct
	portNumber = atoi(argv[3]); // Get the port number, convert to an integer from a string

	serverAddress.sin_family = AF_INET; // Create a network-capable socket
	serverAddress.sin_port = htons(portNumber); // Store the port number
	serverHostInfo = gethostbyname("localhost"); // Convert the machine name into a special form of address

	if (serverHostInfo == NULL){ 
		fprintf(stderr, "CLIENT: ERROR, no such host\n"); 
		exit(0); 
	}

	memcpy((char*)&serverAddress.sin_addr.s_addr, (char*)serverHostInfo->h_addr, serverHostInfo->h_length); // Copy in the address

	// Set up the socket
	socketFD = socket(AF_INET, SOCK_STREAM, 0); // Create the socket
	if (socketFD < 0) {
		error("CLIENT: ERROR opening socket");
	}
	
	// Connect to server
	if (connect(socketFD, (struct sockaddr*)&serverAddress, sizeof(serverAddress)) < 0){ // Connect socket to address
		error("CLIENT: ERROR connecting");
	}

	//authenticate
	bzero(buffer, sizeof(buffer));
	char authenticate[] = "decpassword";
	write(socketFD, authenticate, sizeof(authenticate));
	read(socketFD, buffer, sizeof(buffer));

	if (strcmp(buffer, "correct") != 0){
		fprintf(stderr, "error authenticating\n");
		exit(2);
	}
	//confirmed working authentication
	//https://www.geeksforgeeks.org/lseek-in-c-to-read-the-alternate-nth-byte-and-write-it-in-another-file/
	//https://stackoverflow.com/questions/4823177/reading-a-file-character-by-character-in-c
	//https://stackoverflow.com/questions/14002954/c-programming-how-to-read-the-whole-file-contents-into-a-buffer
	char messageBuffer [70000]; //file4 has a little under 70000 chars
	bzero(messageBuffer, sizeof(messageBuffer));
	int message = open(argv[1], O_RDONLY);
	int messageSize = lseek(message, 0 , SEEK_END);
	//Get entered key and its size
	char keyBuffer[70000];
	bzero(keyBuffer, sizeof(messageBuffer));

	int key = open(argv[2], O_RDONLY);
	int keySize = lseek(key, 0, SEEK_END);

	if(messageSize > keySize){
  		fprintf(stderr, "Error, need longer key");
    	exit(1);
  	}

	//we seeked to end, but need to seek to start for checking
	lseek(message,0,SEEK_SET);
	read(message, messageBuffer, sizeof(messageBuffer));

	lseek(key,0,SEEK_SET);
	read(key, keyBuffer, sizeof(keyBuffer));
		
	int c;
	for (i=0;i<strlen(messageBuffer);i++) {
		c = (int)messageBuffer[i];

		if ( (c < 65 || c > 90) && (c != 32 && c != 10) ){ //can't be anything besides 65-90 and outliers are 32 and 10 (space + \n)
			fprintf(stderr,"Error- bad characters recognized\n");
			exit(1);
		}
		
	}

	bzero(buffer, sizeof(buffer));

	printf("%s\n", messageBuffer);
	printf("%s\n", keyBuffer);
	//now sending file; (make sure to wait to send all bytes)
	//https://stackoverflow.com/questions/26706998/how-many-bytes-should-i-read-write-to-a-socket

	int McharsSent = 0;
	int KcharsSent = 0;
	char sendBuffer[70000];
	char receiveBuffer[70000];
	bzero(sendBuffer, sizeof(sendBuffer));
	bzero(receiveBuffer, sizeof(receiveBuffer));	
	
	//send message
	McharsSent = write(socketFD, messageBuffer, sizeof(sendBuffer)-1);
	if (McharsSent < 0){
		error("socket read error");
	}
	//send key
	KcharsSent = write(socketFD, keyBuffer, sizeof(keyBuffer)-1);
	if (KcharsSent < 0){
		error("socket read error");
	}

	//receive encryption
	charsRead = recv(socketFD, receiveBuffer, sizeof(receiveBuffer)-1, 0);
	if (charsRead < 0){
		error("socket read error");
	}
	printf("%s\n", receiveBuffer);








	

	/*
	// Get input message from user
	printf("CLIENT: Enter text to send to the server, and then hit enter: ");
	memset(buffer, '\0', sizeof(buffer)); // Clear out the buffer array
	fgets(buffer, sizeof(buffer) - 1, stdin); // Get input from the user, trunc to buffer - 1 chars, leaving \0
	buffer[strcspn(buffer, "\n")] = '\0'; // Remove the trailing \n that fgets adds

	// Send message to server
	charsWritten = send(socketFD, buffer, strlen(buffer), 0); // Write to the server
	if (charsWritten < 0) error("CLIENT: ERROR writing to socket");
	if (charsWritten < strlen(buffer)) printf("CLIENT: WARNING: Not all data written to socket!\n");

	// Get return message from server
	memset(buffer, '\0', sizeof(buffer)); // Clear out the buffer again for reuse
	charsRead = recv(socketFD, buffer, sizeof(buffer) - 1, 0); // Read data from the socket, leaving \0 at end
	if (charsRead < 0) error("CLIENT: ERROR reading from socket");
	printf("CLIENT: I received this from the server: \"%s\"\n", buffer);
	*/
	//printf("current buffer:%s\n", buffer);
	close(socketFD); // Close the socket
	return 0;
}