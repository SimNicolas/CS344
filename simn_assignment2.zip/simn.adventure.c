#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdbool.h>
#include <time.h>
#include <dirent.h>
#include <unistd.h>
#include <sys/stat.h>
#include <math.h>
#include <limits.h>
#include <pthread.h>
#include <sys/types.h>
/*
Nicolas Sim CS344 Assignment 2 - adventure
*/

pthread_mutex_t mutex;

//Room struct to be used with associated variables
struct room{
	char* name;
	char* type;
	char connections[7][7]; //largest connection can be "room10\0"
	int numConnections;
};

struct room rooms[7]; //global list of struct room


/* getDir() description-

	This function finds the most current directory that is created using the
	simn.buildrooms.c file and returns the name of the file location
	The base code for this was taken from the 2.4 notes. (Not sure if comments are necessary)
*/
char* getDir(){
	//use struct stat to identify the correct member 
	int newestDirTime = -1;
	char targetDirPrefix[32] = "simn.rooms."; 
	char newestDirName[256];
	memset(newestDirName, '\0', sizeof(newestDirName)); //zero the name of the directory name

	DIR* dirToCheck;
	struct dirent *fileInDir;
	struct stat dirAttributes;
	char* buffer = malloc(sizeof(char) * 100); //dynamically allocate space for buffer
	

	dirToCheck = opendir("."); //open up the directory this program was run in

	if (dirToCheck > 0){
		while ((fileInDir = readdir(dirToCheck)) != NULL){ //checking each entry in dir
			if (strstr(fileInDir->d_name, targetDirPrefix) != NULL){ //for when the entry has a prefix
				
				stat(fileInDir->d_name, &dirAttributes);

				if ((int)dirAttributes.st_mtime > newestDirTime){ //this checks whichever time is larger
					newestDirTime = (int)dirAttributes.st_mtime;
					memset(newestDirName, '\0', sizeof(newestDirName));
					strcpy(newestDirName, fileInDir->d_name);
					strcpy(buffer, fileInDir->d_name);
				}
			}
		}
	}

	closedir(dirToCheck); //close the directory we opened
	
	//TEST** newestDirName contains the directory's name
	//printf("Newest entry found is: %s\n", newestDirName);
	
	
	return buffer;
}


/* makeRooms() description-

	This function opens the latest directory of rooms built
	and makes the correct room names and type in the global array of room struct
	Uses strtok to each line correctly to find distinct keywords in order to get
	the information needed to play the adventure game
*/
//https://www.geeksforgeeks.org/strtok-strtok_r-functions-c-examples/
void makeRooms(){

	FILE *file;
	DIR *directory;
	struct dirent *fileinDir;


	int count = 0;
	char buffer[100];
	char bufferName[100]; 
	char bufferLine[100];


	directory = opendir(getDir()); //opens the directory of the latest made buildrooms file - from getDir()
	if (directory > 0){
		while ((fileinDir = readdir(directory)) != NULL){
			//the first two read names were null from experimentation, so we ignore them
			if (strlen(fileinDir->d_name) > 2){
				sprintf(buffer, "./%s/%s", getDir(), fileinDir->d_name); //open each room file to read
				file = fopen(buffer, "r");
				if (file == NULL){
					printf("Error opening file");
				}

				fgets(buffer, 100, file); //get a line from the file to buffer 
				char* name = strtok(buffer, " ");
				//strtok used to format it correctly
				name = strtok(NULL, " ");
				name = strtok(NULL, "\n");

				strcpy(bufferName, name); //every file in this folder has it's name of the room in the first line
				
				//https://stackoverflow.com/questions/10326586/segmentation-fault-with-strcpy
				
				strcpy(rooms[count].name, bufferName);
				//printf("room name is:%s\n", rooms[count].name);
				int typegotten = 0; //used as a boolean to not allow two types to be read
				int connect_count = 0; //counts the number of connections
				while (feof(file) == 0){ //read until end of file
					
					fgets(buffer, 100, file);
					char* line = strtok(buffer, " ");
					

					if (strcmp(line, "CONNECTION") == 0){ //use strtok to find the first string, and if it's connection we know at the end of the line the connection appears
						//printf("you have 1 connection\n");
						line = strtok(NULL, " ");
						line = strtok(NULL, "\n");
						strcpy(bufferLine, line);
						strcpy(rooms[count].connections[connect_count], bufferLine); //add as connection
						connect_count++;
					}

					else if (strcmp(line, "ROOM") == 0){ //use strtok to find the first string, if it is ROOM then its the room type (we already make sure we get the name of the file)
						if (typegotten == 1){ // goes until end of file and uses last line twice for some reason (use a boolean method to get out of situation)
							
							break;
						}
						
						line = strtok(NULL, " ");
						line = strtok(NULL, "\n");
						strcpy(bufferLine, line);
						strcpy(rooms[count].type, bufferLine); //add as room type
						typegotten = 1;
					}
					
					rooms[count].numConnections = connect_count; //add as number of connections

				}
				count++; //counts up every loop after each file.
				
			}
		}
	}
	
}


/* writeTime() description-
	This function writes the time using time_t and struct tm
	 to a file named currentTime.txt using a particular format
*/
void* writeTime(){
//https://stackoverflow.com/questions/13542345/how-to-convert-st-mtime-which-get-from-stat-function-to-string-or-char
//https://stackoverflow.com/questions/1442116/how-to-get-the-date-and-time-values-in-a-c-program
//https://www.geeksforgeeks.org/strftime-function-in-c/
//https://github.com/angrave/SystemProgramming/wiki/Synchronization,-Part-1:-Mutex-Locks
	
	FILE* outFile;
	char buffer[100];
	struct tm *tm; //time structure
	time_t t; //data type to store time values
	
	
	time(&t);
	tm = localtime (&t);
	
	outFile = fopen("currentTime.txt", "w+"); //name of the file we open

	strftime(buffer, 100, "%I:%M%p, %A, %B %d, %Y", tm); //format the type using sources as help
	fputs(buffer, outFile); //write time to file
	
	fclose(outFile);
	
	return 0;
}


/* readTime() description -
	This function reads the time to a file named currentTime.txt
	and outputs it
*/
void* readTime(){//read from currentTime.txt get to buffer, and print to stdout
	
	char c[1000]; //buffer named c 
    FILE *fptr;

    //checks reading capabilities of currentTime.txt if it exists
    //exits if not readable (null)
    if ((fptr = fopen("currentTime.txt", "r")) == NULL)
    {
        printf("error opening file");
        exit(1);         
    }

    // reads text until newline 
    fscanf(fptr,"%[^\n]", c);

    printf("\n%s\n", c); //outputs time
    fclose(fptr);
	return 0;
}


/* getStartRoom() description -
	This function loops through all rooms that we initialized in makeRooms to find
	the room that has START_ROOM as it's type 
*/
struct room* getStartRoom(){

	struct room* startRoom;
	int i;
	for (i=0; i<7; i++){
		if (strcmp(rooms[i].type, "START_ROOM") == 0){ //if the room has type start_room
			startRoom = &rooms[i];	//startroom holds the reference to the room in rooms
		}
	}
	return startRoom;
}


/* getRoom() description -
	This function takes a char* input to compare to all room in the global rooms and returns the corresponding room
	This function should only be used if the input is guaranteed to be in rooms

*/
struct room* getRoom(char* input){
	struct room* currRoom;
	int i;
	for (i=0; i<7; i++){
		if (strcmp(rooms[i].name, input) == 0){
			currRoom = &rooms[i];
		}
	}
	return currRoom;
}


/* timeThread() description -
	This function is a time thread to allow the writing of time to be
	a separate process using mutex and threads.
*/
void timeThread(){
	//https://www.cs.cmu.edu/afs/cs/academic/class/15492-f07/www/pthreads.html
	//https://stackoverflow.com/questions/42861913/why-use-usleep-and-not-sleep
	//http://www.yolinux.com/TUTORIALS/LinuxTutorialPosixThreads.html
	//https://stackoverflow.com/questions/14888027/mutex-lock-threads
	int timeThread;

	pthread_t thread;
	pthread_mutex_init(&mutex, NULL);
	pthread_mutex_lock(&mutex); //locked out for time to be written 

	timeThread = pthread_create(&thread, NULL, writeTime, NULL);

	pthread_mutex_unlock(&mutex); //unlocked mutex 
	pthread_mutex_destroy(&mutex); //destroy mutex

	sleep(1); //sleeps for 1 second


}


/* main() description -
	The function to allocate memory to rooms, initialize making of rooms by reading the correct
	file and ultimately the game loop.
*/
int main(){
	char room_input[100];
	char prevRooms[100][10]; //2d array that holds previous rooms
	int roomCounter;
	char* roomNum = getDir();
	
	int i, j;
	//allocate memory to each room
	for (i = 0; i < 7; i++){
		//allocate memory and "zero" it for each name and type in our rooms holder for each room
	rooms[i].name = calloc(6, sizeof(char));
	rooms[i].type = calloc(11, sizeof(char));
	rooms[i].numConnections = 0;
	memset(rooms[i].connections,'\0', sizeof rooms[i].connections);
	}
	roomCounter = 0; //room counter to remember how many previous rooms are held in prevRooms[][]
	makeRooms(); //initializes all the rooms with correct information by reading from latest directory

	struct room* currentRoom; //room struct to hold the room
	currentRoom = getStartRoom(); //uses function to get the room in rooms associated with the type start_room
	int isEnd;
	isEnd = 0; //used as a boolean to see if it's the room chosen is the end_room
	int isValidInput;
	isValidInput = 0; //used as a boolean to see if the input is valid
	do{
		printf("\nCURRENT LOCATION: %s\n", currentRoom->name);
		printf("POSSIBLE CONNECTIONS: ");
		
		for(i=0; i < currentRoom->numConnections; i++){
			if (i > 0){
				printf(", ");
			}
			printf("%s", currentRoom->connections[i]);
		}
		printf(". \nWHERE TO? >");
		isValidInput = 0;
		scanf("%s", room_input);

		if (strcmp(room_input, "time") == 0){
			timeThread(); //time thread used here (with mutex) to prevent usage of the currentTime.txt resource before time is written
			readTime(); //mutex should be unlocked and is able to read from currentTime.txt
			isValidInput = 1;
		}

		else{
			for (i=0; i< currentRoom->numConnections; i++){ //loops through all of the current room's connections to see if input is one fo the connections
				if (strcmp(currentRoom->connections[i], room_input) == 0){ 
					//instance where the input is one of the current room's connections
					currentRoom = getRoom(room_input); //current name is changed because input was valid
					strcpy(prevRooms[roomCounter], currentRoom->name); //the next room is confirmed to be on our path so added to prevRooms array
					roomCounter++;
					isValidInput = 1;
					//add previous room to a list so we can list path taken to end
					//add step counter
				}

				
			}
			if (isValidInput == 0){
				printf("\nHUH? I DON'T UNDERSTAND THAT ROOM. TRY AGAIN. \n"); //The input was not valid.
			}


		}

		if (strcmp(currentRoom->type, "END_ROOM") == 0){ //checks to see if the current room chosen has a type of end_room to end the game
			isEnd = 1;
		}
		
	}while (isEnd == 0); //or if step counter reaches a max -> not a necessary requirement
	//once you leave loop check if current room is end_room, if yes then print steps and congrats
	if(strcmp(currentRoom->type, "END_ROOM") == 0){
		printf("\nYOU HAVE FOUND THE END ROOM - %s. CONGRATULATIONS!", currentRoom->name);
		printf("\nYOU TOOK %d STEPS. YOUR PATH TO VICTORY WAS:\n", roomCounter);
		for(i=0; i < roomCounter; i++){
			printf("%s\n", prevRooms[i]); //loop through prevRooms to show path taken
		}
	}

	/************** TESTS TO DELETE LATER

	//strcpy(rooms[0].connections[0], "room1");
	//printf("\n%s\n", rooms[0].connections[0]);

	***************/
	/*
	printf("\n");
	for (i=0; i < 7; i++){
		printf("room name is:%s\n", rooms[i].name);
		printf("room type is:%s\n", rooms[i].type);
		for (j=0; j < 6; j++){
			printf("room connection:%s\n", rooms[i].connections[j]);
		}
		printf("room connection count is: %d\n", rooms[i].numConnections);
	}
	printf("TEST\n%s\n", currentRoom->name);
	//struct room* currentRoom;
	//currentRoom = getStartRoom();
	*/
	

	return 0;
}
