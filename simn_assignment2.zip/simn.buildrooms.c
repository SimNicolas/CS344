#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdbool.h>
#include <time.h>
#include <dirent.h>
#include <unistd.h>
#include <sys/stat.h>
#include <math.h>
/*
https://stackoverflow.com/questions/3389464/initializing-a-structure-array-using-memset
https://stackoverflow.com/questions/30067436/connect-rooms-randomly-in-adventure-game
https://stackoverflow.com/questions/5636070/zero-an-array-in-c-code
https://stackoverflow.com/questions/3389464/initializing-a-structure-array-using-memset
https://stackoverflow.com/questions/1658476/c-fopen-vs-open
*/
//char* roomNames[10] = {"room1", "room2", "room3", "room4", "room5", "room6", "room7", "room8", "room9", "room10"};
//char* roomTypes[3] = {"START_ROOM", "MID_ROOM", "END_ROOM"};

struct room{
	char* name;
	char* type;
	int connections[6];//can only have 6 connections at max because theres only 7 rooms (can't connect with self)
	int numConnections;
};


struct room rooms[7]; //global array of room structs


bool isGraphFull(){
	int i = 0;
	bool isFull = true;
	for(i = 0; i < 7; i++){
		//returns false if each room has less than 3 connections
		if(rooms[i].numConnections < 3){
			isFull = false;
			return isFull;
		}
	}
	return isFull;
}

bool addToConnections(struct room* x){ 
	bool canConnect = false;
	if (x->numConnections < 6){ //if the current rooms number of connections is less than 6 return true, else return false
		canConnect = true;
		return canConnect;
	}
	return canConnect;
}

bool connectionExists(struct room* x, struct room* y){ //a boolean to see if 2 rooms connection exists
	int i = 0;
	bool connectionExists = false;
	int connectionCount = x->numConnections;
	//checks connection of the room parameters x and y
	for( i = 0; i < connectionCount; i++){
		if( !strcmp(rooms[ x->connections[i] ].name, y->name)){
			connectionExists = true;
			return connectionExists;
		}
	}
	return connectionExists;
}

int findIndex(struct room* x){
	//a function used to check the index of a room in rooms
	int index = 0;
	int i = 0;
	int count = 7;
	for (i = 0; i < count; i++){
		if ( !strcmp(x->name, rooms[i].name) ){
			index = i;
			return index;
		}
	}
	return index;
}

void connectRooms(struct room* x, struct room* y){
	//this step is done after we are sure that room x and y can be added to each other's connections
	int xCount = x->numConnections;
	int yCount = y->numConnections;

	//connections of each room hold the index of the room in rooms and not the actual room
	x->connections[xCount] = findIndex(y);
	y->connections[yCount] = findIndex(x);

	xCount++;
	yCount++;

	x->numConnections = xCount;
	y->numConnections = yCount;
}

bool isSameRoom(struct room* x, struct room* y){
	bool isSame = false;

	if ( !strcmp(x->name, y->name) ){ //return value 0 when equal
		isSame = true;
		return isSame;
	}
	return isSame;
}

struct room* getRandomRoom(){
	//using the rand() function we return a random room in rooms 
	int r = rand() % 7;
	return &rooms[r];
}

void addConnections(){ // the function that connects two random rooms together
	struct room* A;
	struct room* B;

	while(true){
		A = getRandomRoom();

		if (addToConnections(A) == true){
			//printf("\n%s is room A\n", A->name);
			break;
		}
	}

	do{
		B = getRandomRoom();
		//printf("\n%s is room B\n", B->name);
	}
	while(isSameRoom(A,B) == true || addToConnections(B) == false || connectionExists(A,B) == true);

	connectRooms(A, B);
}





/*

Initialize 7 random rooms out of 10 in an array of structs
initialize their room type.

*/
char roomNames[10][10] = {"room1", "room2", "room3", "room4", "room5", "room6", "room7", "room8", "room9", "room10"};
char roomTypes[3][11] = {"START_ROOM", "MID_ROOM", "END_ROOM"};

int main(){
	int i = 0; //iterator holder
	int j = 0;
	int r = 0; //random holder

	char fileBuffer[50];
	pid_t pid = getpid();
	FILE *outFile;

	int takenNames[10] = {0}; //a dictionary to remember what room names have been used (zeroed for recognizing which indices were used)
	int takenTypes[7] = {0}; //a dictionary to remember what room types have been used
	srand(time(NULL));


	//calloc memory for room name
	for(i = 0; i < 7; i++){
		rooms[i].name = calloc(6, sizeof(char));
		r = rand() % 10;
		if (takenNames[r] == 0){
			strcpy(rooms[i].name, roomNames[r]);
			takenNames[r] = 1;
		}
		else{
			while(takenNames[r] == 1){
				r = rand() % 10;
				//randomizer until we find a non used takenName
			}
			strcpy(rooms[i].name, roomNames[r]);
			takenNames[r] = 1;
		}
	}
	//assign room types
	//this is a separate case to randomize the start room
	r = rand() % 7;
	rooms[r].type = calloc(11, sizeof(char));
	strcpy(rooms[r].type, roomTypes[0]);
	takenTypes[r] = 1;

	while(takenTypes[r] == 1){
		r = rand() % 7;
	}

	//after finding a new random number, calloc and find a finish room
	rooms[r].type = calloc(11, sizeof(char));
	strcpy(rooms[r].type, roomTypes[2]);
	takenTypes[r] = 1;

	//calloc and assign mid_room to all other rooms
	for(i = 0; i < 7; i++){

		if(takenTypes[i] == 0){
			rooms[i].type = calloc(11, sizeof(char));
			strcpy(rooms[i].type, roomTypes[1]);
		}
		else{
			continue;
		}
	}


	while(isGraphFull() == false){
		//after all rooms are assigned to their appropriate names and types
		//we run addConnections() function to add at least 3 connections to each room
		addConnections(); 
	}

	//this is the formatting code for writing to a file in it's
	//unique file using pid
	sprintf(fileBuffer, "simn.rooms.%d", (int)pid);

	if (mkdir(fileBuffer, 0755) != 0){
		perror("Error in making directory\n");
		return 1;
	}
	for (i = 0; i < 7; i++){
		sprintf(fileBuffer, "./simn.rooms.%d/%s", (int)pid, rooms[i].name); //creates the name of the room file using the unique pid and it's room name

		outFile = fopen(fileBuffer, "w");
		if (outFile == NULL){
			perror("Error opening file\n");
			return 1;
		}
		//the file is written into using the below format using each room's information.

		sprintf(fileBuffer, "ROOM NAME: %s\n", rooms[i].name);

		fputs(fileBuffer, outFile);

		for (j = 0; j < rooms[i].numConnections; j++){
			sprintf(fileBuffer, "CONNECTION %d: %s\n", j+1, rooms[ rooms[i].connections[j] ].name);
			
			fputs(fileBuffer, outFile);
		}
		sprintf(fileBuffer, "ROOM TYPE: %s\n", rooms[i].type);
		fputs(fileBuffer, outFile);

		fclose(outFile);
	}

	return 0;


}