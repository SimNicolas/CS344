how to compile:

gcc -o smallsh smallsh.c




how to run:

./smallsh