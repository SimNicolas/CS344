#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <signal.h>
#include <unistd.h>
#include <fcntl.h>

#define MAX 2048
#define MAX_ARGS 512


void catchSIGINT(int signal);
void catchSIGTSTP(int signal);
void printStatus(int status);

void catchSIGINT(int signal)
{
	char* message = "\nSIGINT signal caught.\n";
	write(STDOUT_FILENO, message, 29);
}

//global variable bgToggle- background toggle to determine if mode is enabled or not
//correspons to this signal catch
int bgToggle = 1;
void catchSIGTSTP(int signal)
{
	if (bgToggle == 1){ //1 means it was in background mode (going to foreground-only mode)
		bgToggle = 0;
		char* message = "\nForeground-only. (& will be ignored)\n";
		write(STDOUT_FILENO, message, 37);
	}
	else{
		bgToggle = 1;
		char* message = "\nNormal Conditions\n";
		write(STDOUT_FILENO, message, 19);
	}
}

//shows status when interrupted or manually.
void printStatus(int status){
	if(WIFEXITED(status)){
		printf("exit value %i\n", WEXITSTATUS(status));
	}
	else{
		printf("terminated by signal %i\n", status);
	}
	return;
}

int main()
{
	//ctrl-c sends SIGINT && ctrl-z sends SIGTSTP

	//ctrl-c catch
	struct sigaction SIGINT_action = {0};
	SIGINT_action.sa_handler = SIG_IGN;
	SIGINT_action.sa_flags = 0;
	sigfillset(&SIGINT_action.sa_mask);
	sigaction(SIGINT, &SIGINT_action, NULL);

	//ctrl-z catch
	struct sigaction SIGTSTP_action = {0};
	SIGTSTP_action.sa_handler = catchSIGTSTP;
	SIGTSTP_action.sa_flags = 0;
	sigfillset(&(SIGTSTP_action.sa_mask));
	sigaction(SIGTSTP, &SIGTSTP_action, NULL);

	char mystring[MAX]; //input known as mystring
	char* arguments[MAX_ARGS]; //from the input, gathers all separate args in this array
	int maxchars = MAX + 1;
	char* input;
	int num_arguments;
	char* input_file;
	char* output_file;
	int inForeground;
	pid_t cpid;
	int status = 0;
	int inputExists = 0;
	int outputExists = 0;
	int fileDescr = -1;
	int fileDescr2 = -1; 
	//int i;

	while(1) //while loop until exited (with prompt of :)
	{
		// Get input from the user
		fflush(stdout);
		printf(": "); //prompt : to indicate shell is ready for input
		fflush(stdout); //flush stdout
		inForeground = 1; //default is done in foreground
		if(!bgToggle){ //checks after every loop (could've implemented this better)
			inForeground = 1;
		}
		input_file = NULL;
		output_file = NULL;
		inputExists = 0;
		outputExists = 0;
		status = 0;

		//https://www.geeksforgeeks.org/fgets-gets-c-language/
		//http://www.cplusplus.com/reference/cstdio/fgets/
		//https://stackoverflow.com/questions/4177955/how-to-prevent-the-user-from-entering-more-data-than-the-maximum-limit
		if (fgets(mystring, maxchars, stdin)){ //won't allow more than 2048 characters from command line
			if(NULL == strchr(mystring, '\n')){
				printf("maximum stdin length reached.\n");
				return 0;
			}
			else{
				num_arguments = 0;
				//take input and see if >, <, or & was used
				input = strtok(mystring, " \n");
				
				// order ex: wc < junk > junk2
				if (input == NULL){
					arguments[0] = NULL;
				}	

				while(input != NULL && num_arguments < MAX_ARGS){//NULL indicates no more token https://stackoverflow.com/questions/29764244/delimiter-for-end-of-file-string
					//read until end of line using strtok to read special characters
					if(strcmp(input, "<") == 0){
						//take next line as the input file
						input = strtok(NULL, " \n");//delimiters possible are space and newline
						input_file = input;
						inputExists = 1;
						
					}

					else if (strcmp(input, ">") == 0){
						//take next strtok as the output file
						input = strtok(NULL, " \n");
						output_file = input;
						outputExists = 1;
					}
					
					else{
						//store argument and increment counter
						arguments[num_arguments] = input;
						num_arguments++;
						arguments[num_arguments] = NULL; //next argument is set to NULL just in case
						
					}
					input = strtok(NULL, " \n"); //get next argument

				}


				if(arguments[0] == NULL || *arguments[0] == '#'){ //checks to see if NULL or comment
					continue;
				}

				
				/*for (int i = 0; i< num_arguments; i++){
					printf("%s\n", arguments[i]);
				}*/
				//test
				//printf("input file: %s\n", input_file);
				//printf("output file: %s\n", output_file);



				//input is read for input/output file and separated in arguments[]
				//exit, cd, and status
				else if(strcmp(arguments[0], "exit") == 0){
					//printf("exit command entered.\n");
					exit(0);
				}

				else if(strcmp(arguments[0], "cd") == 0){
					//printf("cd command entered.\n");
					if(arguments[1] == NULL){
						chdir(getenv("HOME"));
					}
					else{
						chdir(arguments[1]);
					}
				}

				else if(strcmp(arguments[0], "status") == 0){
					printStatus(status);
				}



				else{
					//execvp(arguments[0], arguments);
					//error
					//printf("smallsh: sorry command not valid");
					//fflush(stdout);
					//_Exit(1);
					if(strcmp(arguments[num_arguments-1], "&") == 0){//last is NULL so check second to last in arguments to find a &
						inForeground = 0;
					}
					cpid = fork(); //fork a new process and run switch 
					switch(cpid){
						//base code from lecture
						case -1: 
							perror("Error.\n");
							return (1);
							break;

						case 0:
						//do execvp here (check for input/output files and foreground/background)
							if(inForeground){
								SIGINT_action.sa_handler = SIG_DFL;
								sigaction(SIGINT, &SIGINT_action, NULL);
							}
							if(inputExists == 1){
								//check to see if input file was given
								fileDescr = open(input_file, O_RDONLY);

								if(fileDescr == -1){
									printf("cannot open %s for input\n", input_file);
									fflush(stdout);
									_Exit(1);
								}
								if(dup2(fileDescr, 0) == -1){
									perror("dup2");
									_Exit(1);
								}
								close(fileDescr);
							}

							else if (!inForeground){
								fileDescr = open("/dev/null", O_RDONLY);
								if(fileDescr == -1){
									perror("open");
									_Exit(1);
								}
								if(dup2(fileDescr, 0) == -1){
									perror("dup2");
									_Exit(1);
								}
							}

							if (outputExists == 1){
								//checks to see if output file was given
								fileDescr2 = open(output_file, O_WRONLY | O_CREAT | O_TRUNC, 0644);
								if(fileDescr2 == -1){
									printf("cannot open %s for output\n", output_file);
								}
								if(dup2(fileDescr2, 1) == -1){
									perror("dup2");
									_Exit(1);
								}
								close(fileDescr2);
							}

							//replace process with exec
							execvp(arguments[0], arguments);

							//if it doesn't, then an error has occured
							printf("Invalid Command.\n");
							fflush(stdout);
							exit(1);

						default:
							
								if(inForeground){ //if it's a foreground process
									waitpid(cpid, &status, 0); //this waits for last child process to finish
								}
								else{ //if it's a background process
									printf("background PID: %i\n", cpid);
									break;
								}
							

				
					}
				}

				//end - cleanup
				cpid = waitpid(-1, &status, WNOHANG); //waiting for foreground process
				
				while(cpid > 0){
					printf("background process, %i, is done: exit value %d\n", cpid, WEXITSTATUS(status));
					fflush(stdout);
					cpid = waitpid(-1, &status, WNOHANG);
				}

	  		}

		}

	  //TODO 
	  /*
		  command line format- command [arg1...] [<] [>] [&]
		  <, >, and & are special look for them first in input
		  (& only at end then exec in background)
		  Check for blank lines and commend (first char is #)

		  After these checks, check for built-in commands (exit, cd, status)
		  (cannot run in background - ignore if & is added)

		  For non-built in command - fork() off a child then 
		  run exec on command

	  */
	}
	return 0;
}
